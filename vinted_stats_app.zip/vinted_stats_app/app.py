import re
from datetime import datetime, timedelta

import pandas as pd
import streamlit as st
import plotly.express as px

st.set_page_config(page_title="Vinted Sneaker Stats", layout="wide")

REQUIRED_COLUMNS = {"model", "price", "sold_at"}

SAMPLE = pd.DataFrame([
    {"model": "Adidas Samba", "size": "42", "price": 45, "sold_at": "2026-06-30 10:12"},
    {"model": "Adidas Samba", "size": "43", "price": 43, "sold_at": "2026-06-30 13:42"},
    {"model": "Adidas Samba", "size": "38", "price": 44, "sold_at": "2026-06-29 19:20"},
    {"model": "Nike Killshot 2", "size": "42", "price": 52, "sold_at": "2026-06-30 09:20"},
    {"model": "Nike Killshot 2", "size": "41", "price": 49, "sold_at": "2026-06-28 18:20"},
    {"model": "New Balance 550", "size": "44", "price": 61, "sold_at": "2026-06-30 16:00"},
])


def normalize_model(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"\s+", " ", text)
    return text.title()


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.strip().lower() for c in df.columns]
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Faltan columnas obligatorias: {', '.join(sorted(missing))}")

    df["model"] = df["model"].map(normalize_model)
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["sold_at"] = pd.to_datetime(df["sold_at"], errors="coerce")
    if "size" in df.columns:
        df["size"] = df["size"].astype(str).str.replace(",", ".", regex=False).str.strip()
    else:
        df["size"] = ""

    df = df.dropna(subset=["model", "price", "sold_at"])
    df = df[df["price"] > 0]
    return df


def summarize(df: pd.DataFrame, days: int) -> pd.DataFrame:
    cutoff = pd.Timestamp.now() - pd.Timedelta(days=days)
    filtered = df[df["sold_at"] >= cutoff]
    if filtered.empty:
        return pd.DataFrame(columns=["Modelo", "Ventas", "Ventas/día", "Precio medio", "Precio mediano", "Mín", "Máx"])
    out = (
        filtered.groupby("model")
        .agg(
            Ventas=("model", "count"),
            **{"Precio medio": ("price", "mean"), "Precio mediano": ("price", "median"), "Mín": ("price", "min"), "Máx": ("price", "max")},
        )
        .reset_index()
        .rename(columns={"model": "Modelo"})
    )
    out["Ventas/día"] = out["Ventas"] / max(days, 1)
    return out.sort_values(["Ventas/día", "Precio medio"], ascending=False)


def model_detail(df: pd.DataFrame, model: str, days: int) -> pd.DataFrame:
    cutoff = pd.Timestamp.now() - pd.Timedelta(days=days)
    return df[(df["model"] == model) & (df["sold_at"] >= cutoff)].copy()


st.title("Vinted Sneaker Stats")
st.caption("Dashboard para estimar ventas diarias, precio medio y demanda por talla a partir de datos de ventas.")

with st.sidebar:
    st.header("Datos")
    uploaded = st.file_uploader("Sube un CSV", type=["csv"])
    st.markdown("Columnas mínimas: `model`, `price`, `sold_at`. Opcional: `size`.")
    days = st.slider("Periodo de análisis", 1, 90, 30)
    use_sample = st.toggle("Usar datos de ejemplo", value=uploaded is None)

try:
    if uploaded is not None and not use_sample:
        raw_df = pd.read_csv(uploaded)
    else:
        raw_df = SAMPLE
    df = clean_data(raw_df)
except Exception as exc:
    st.error(str(exc))
    st.stop()

summary = summarize(df, days)

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.metric("Modelos", int(df["model"].nunique()))
with c2:
    st.metric("Ventas analizadas", int(len(df)))
with c3:
    st.metric("Precio medio global", f"{df['price'].mean():.2f} €")
with c4:
    st.metric("Periodo", f"{days} días")

st.subheader("Ranking de modelos")
st.dataframe(
    summary.style.format({"Ventas/día": "{:.2f}", "Precio medio": "{:.2f} €", "Precio mediano": "{:.2f} €", "Mín": "{:.2f} €", "Máx": "{:.2f} €"}),
    use_container_width=True,
)

if not summary.empty:
    selected = st.selectbox("Modelo concreto", summary["Modelo"].tolist())
    detail = model_detail(df, selected, days)
    avg_price = detail["price"].mean()
    daily_sales = len(detail) / days

    st.subheader(selected)
    m1, m2, m3 = st.columns(3)
    m1.metric("Valor medio", f"{avg_price:.2f} €")
    m2.metric("Ventas diarias estimadas", f"{daily_sales:.2f}")
    m3.metric("Ventas en periodo", int(len(detail)))

    sales_by_day = detail.assign(day=detail["sold_at"].dt.date).groupby("day").size().reset_index(name="ventas")
    fig = px.bar(sales_by_day, x="day", y="ventas", title="Ventas por día")
    st.plotly_chart(fig, use_container_width=True)

    if detail["size"].astype(str).str.len().sum() > 0:
        size_stats = (
            detail.groupby("size")
            .agg(vendidos=("size", "count"), precio_medio=("price", "mean"))
            .reset_index()
            .sort_values("vendidos", ascending=False)
        )
        st.subheader("Desglose por talla")
        st.dataframe(size_stats.style.format({"precio_medio": "{:.2f} €"}), use_container_width=True)

st.subheader("Últimas ventas cargadas")
st.dataframe(df.sort_values("sold_at", ascending=False), use_container_width=True)

st.info("Nota: esta app no automatiza scraping de Vinted. Está preparada para analizar datos que tú importes legalmente en CSV.")
