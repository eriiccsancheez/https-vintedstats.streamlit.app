# Vinted Sneaker Stats

App local para analizar ventas de zapatillas en Vinted a partir de un CSV.

## Instalación

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py
```

## Formato del CSV

Columnas obligatorias:

```csv
model,price,sold_at,size
Adidas Samba,44,2026-06-30 10:15,42
Nike Killshot 2,52,2026-06-30 11:40,43
```

- `model`: modelo de zapatilla.
- `price`: precio vendido en euros.
- `sold_at`: fecha/hora de venta.
- `size`: talla, opcional.

## Qué calcula

- Ventas por modelo.
- Ventas medias por día.
- Precio medio, mediano, mínimo y máximo.
- Ranking de modelos.
- Desglose por talla.
- Gráfico de ventas diarias.

## Importante

No incluye scraping automático de Vinted. Para hacerlo en producción conviene usar una fuente de datos autorizada o una API/partner, porque scraping no autorizado puede incumplir condiciones de uso o bloquear cuentas/IPs.
